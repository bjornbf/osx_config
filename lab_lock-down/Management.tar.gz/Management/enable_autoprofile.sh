#!/bin/bash
sudo defaults write com.apple.loginwindow LoginHook /Library/Management/login-wrapper.sh