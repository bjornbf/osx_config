#!/bin/tcsh -f
/usr/sbin/vsdbutil -d /Volumes/Video
