#!/bin/bash
defaults read com.apple.loginwindow LoginHook

