#!/bin/bash
sudo defaults write com.apple.loginwindow LoginHook ""