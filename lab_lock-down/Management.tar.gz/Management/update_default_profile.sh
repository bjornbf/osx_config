#!/bin/bash
sudo ditto -rsrcFork /Users/lmok /Library/Management/lmok.lproj
